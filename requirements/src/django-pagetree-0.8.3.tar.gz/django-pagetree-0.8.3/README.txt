pagetree is a helper for building sites that are organized
as a hierarchy of pages which the user/visitor goes through 
in (depth-first) order. 

the pages can then each have 'blocks' attached to them which 
are content or interactive things. 

see django-pageblocks for a basic set of these blocks.

pagetree is designed to allow this kind of site to be built by 
an editor through the web. it aims to provide the minimum amount
of functionality possible and stay out of the way as much
as possible.
